package com.papahouse.customer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class PlaceOrderActivity extends AppCompatActivity {

    private EditText edtName, edtItems, edtTotal;
    private Button btnPlaceOrder;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);

        edtName = findViewById(R.id.edtName);
        edtItems = findViewById(R.id.edtItems);
        edtTotal = findViewById(R.id.edtTotal);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);

        db = FirebaseFirestore.getInstance();

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        String name = edtName.getText().toString().trim();
        String items = edtItems.getText().toString().trim();
        String totalText = edtTotal.getText().toString().trim();

        if (name.isEmpty() || items.isEmpty() || totalText.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        double total = Double.parseDouble(totalText);
        long timestamp = System.currentTimeMillis();

        String orderId = db.collection("orders").document().getId();

        Map<String, Object> order = new HashMap<>();
        order.put("orderId", orderId);
        order.put("name", name);
        order.put("items", items);
        order.put("total", total);
        order.put("status", "Pending");
        order.put("timestamp", timestamp);

        db.collection("orders")
                .document(orderId)
                .set(order)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Order Submitted!", Toast.LENGTH_SHORT).show();
                    edtName.setText("");
                    edtItems.setText("");
                    edtTotal.setText("");
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }
}
