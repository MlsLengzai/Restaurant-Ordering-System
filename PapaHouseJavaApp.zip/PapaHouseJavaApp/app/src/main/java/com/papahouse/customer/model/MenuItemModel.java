package com.papahouse.customer.model;

public class MenuItemModel {

    public String id;
    public String name;
    public double price;
    public int imageRes;
    public String category;

    public MenuItemModel() {
    }

    public MenuItemModel(String id, String name, double price, int imageRes, String category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.imageRes = imageRes;
        this.category = category;
    }

    // Optional getters
    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getImageRes() { return imageRes; }
    public String getCategory() { return category; }
}
