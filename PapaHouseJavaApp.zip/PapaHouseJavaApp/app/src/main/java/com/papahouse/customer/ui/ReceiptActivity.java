package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartRepo;
import com.papahouse.customer.ui.adapter.OrderSummaryAdapter;

import java.util.Locale;

public class ReceiptActivity extends AppCompatActivity {

    TextView txtOrderId, txtMethod, txtTotal;
    RecyclerView rvItems;
    MaterialButton btnDone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);


        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        if (toolbar != null) toolbar.setNavigationOnClickListener(v -> navigateHome());

        txtOrderId = findViewById(R.id.txtOrderId);
        txtMethod = findViewById(R.id.txtMethod);
        txtTotal = findViewById(R.id.txtTotal);
        rvItems = findViewById(R.id.rvItems);
        btnDone = findViewById(R.id.btnDone);


        txtOrderId.setText("Order ID: #" + String.format("%04d", (int) (Math.random() * 9999)));


        String method = getIntent().getStringExtra("method");
        txtMethod.setText("Payment Method: " + (method != null ? method : "Unknown"));


        rvItems.setLayoutManager(new LinearLayoutManager(this));
        rvItems.setAdapter(new OrderSummaryAdapter(CartRepo.get().items()));


        txtTotal.setText(String.format(Locale.getDefault(), "Total: RM %.2f", CartRepo.get().total()));


        btnDone.setOnClickListener(v -> {
            CartRepo.get().clear(); //clear
            navigateHome();
        });
    }

    private void navigateHome() {
        Intent i = new Intent(this, MainActivity.class);

        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        navigateHome();
    }
}
