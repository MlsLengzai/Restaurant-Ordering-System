package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.papahouse.customer.R;
import com.papahouse.customer.model.OrderModel;
import com.papahouse.customer.ui.adapter.OrderHistoryAdapter;

import java.util.ArrayList;

public class OrderHistoryActivity extends AppCompatActivity {

    private final ArrayList<OrderModel> orders = new ArrayList<>();
    private OrderHistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_order_history);

        RecyclerView rv = findViewById(R.id.rvOrders);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new OrderHistoryAdapter(orders, order -> {
            Intent i = new Intent(this, OrderTrackingActivity.class);
            i.putExtra("orderId", order.getOrderId());
            startActivity(i);
        });
        rv.setAdapter(adapter);

        // ✅ UNIQUE CUSTOMER ID
        String customerId = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ANDROID_ID
        );

        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereEqualTo("customerId", customerId) // ⭐ KEY FIX
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (snap == null) return;
                    orders.clear();
                    orders.addAll(snap.toObjects(OrderModel.class));
                    adapter.notifyDataSetChanged();
                });
    }
}
