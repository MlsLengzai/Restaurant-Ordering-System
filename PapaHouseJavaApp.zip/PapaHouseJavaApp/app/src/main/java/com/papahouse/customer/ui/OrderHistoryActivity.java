package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.papahouse.customer.R;
import com.papahouse.customer.model.OrderModel;
import com.papahouse.customer.ui.adapter.OrderHistoryAdapter;
import com.papahouse.customer.ui.util.DeviceIdManager; // ✅ Import the new helper

import java.util.ArrayList;

public class OrderHistoryActivity extends AppCompatActivity {

    private final ArrayList<OrderModel> orders = new ArrayList<>();
    private OrderHistoryAdapter adapter;
    private View layoutEmpty;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_order_history);

        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        toolbar.setNavigationOnClickListener(v -> finish());

        layoutEmpty = findViewById(R.id.layoutEmpty);
        RecyclerView rv = findViewById(R.id.rvOrders);
        rv.setLayoutManager(new LinearLayoutManager(this));

        adapter = new OrderHistoryAdapter(orders, order -> {
            Intent i = new Intent(this, OrderTrackingActivity.class);
            i.putExtra("orderId", order.getOrderId());
            startActivity(i);
        });
        rv.setAdapter(adapter);

        loadOrders();
    }

    private void loadOrders() {
        // ✅ FIXED: Use DeviceIdManager to find the correct orders
        String customerId = DeviceIdManager.get(this);

        FirebaseFirestore.getInstance()
                .collection("orders")
                .whereEqualTo("customerId", customerId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (snap == null) return;
                    orders.clear();
                    orders.addAll(snap.toObjects(OrderModel.class));
                    adapter.notifyDataSetChanged();

                    if (orders.isEmpty()) {
                        layoutEmpty.setVisibility(View.VISIBLE);
                        findViewById(R.id.rvOrders).setVisibility(View.GONE);
                    } else {
                        layoutEmpty.setVisibility(View.GONE);
                        findViewById(R.id.rvOrders).setVisibility(View.VISIBLE);
                    }
                });
    }
}