package com.papahouse.customer.ui; // ✅ FIXED: Changed to match current folder

import android.graphics.Color;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.papahouse.customer.R;
import com.papahouse.customer.model.OrderModel;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.VH> {

    public interface Click {
        void onClick(OrderModel o);
    }

    private final List<OrderModel> list;
    private final Click click;

    public OrderHistoryAdapter(List<OrderModel> list, Click click) {
        this.list = list;
        this.click = click;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_history, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        OrderModel o = list.get(i);

        String displayId = o.getOrderId().length() > 6
                ? o.getOrderId().substring(0, 6).toUpperCase()
                : o.getOrderId();
        h.txtId.setText("Order #" + displayId);

        h.txtTotal.setText(String.format(Locale.getDefault(), "RM %.2f", o.getTotal()));

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(o.getTimestamp());
        String date = DateFormat.format("dd MMM yyyy, h:mm a", cal).toString();
        h.txtDate.setText(date);

        h.chipStatus.setText(o.getStatus());
        String status = o.getStatus() != null ? o.getStatus().toLowerCase() : "";

        if (status.contains("pending")) {
            h.chipStatus.setChipBackgroundColorResource(android.R.color.holo_orange_light);
            h.chipStatus.setTextColor(Color.BLACK);
        } else if (status.contains("cooking") || status.contains("preparing")) {
            h.chipStatus.setChipBackgroundColorResource(android.R.color.holo_blue_light);
            h.chipStatus.setTextColor(Color.BLACK);
        } else if (status.contains("completed") || status.contains("delivered")) {
            h.chipStatus.setChipBackgroundColorResource(android.R.color.holo_green_light);
            h.chipStatus.setTextColor(Color.BLACK);
        } else {
            h.chipStatus.setChipBackgroundColorResource(android.R.color.darker_gray);
            h.chipStatus.setTextColor(Color.WHITE);
        }

        h.itemView.setOnClickListener(v -> click.onClick(o));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView txtId, txtDate, txtTotal;
        Chip chipStatus;

        VH(@NonNull View v) {
            super(v);
            txtId = v.findViewById(R.id.txtOrderId);
            txtDate = v.findViewById(R.id.txtDate);
            txtTotal = v.findViewById(R.id.txtTotal);
            chipStatus = v.findViewById(R.id.chipStatus);
        }
    }
}