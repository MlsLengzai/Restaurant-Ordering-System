package com.papahouse.customer.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.papahouse.customer.R;
import com.papahouse.customer.model.OrderModel;

import java.util.List;
import java.util.Locale;

public class OrderHistoryAdapter extends RecyclerView.Adapter<OrderHistoryAdapter.VH> {

    public interface Click {
        void onClick(OrderModel o);
    }

    private final List<OrderModel> list;
    private final Click click;

    public OrderHistoryAdapter(List<OrderModel> list, Click click) {
        this.list = list;
        this.click = click;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_history, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        OrderModel o = list.get(i);

        h.txtId.setText("Order #" + o.getOrderId());
        h.txtStatus.setText(o.getStatus());
        h.txtTotal.setText(String.format(Locale.getDefault(), "RM %.2f", o.getTotal()));

        h.itemView.setOnClickListener(v -> click.onClick(o));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView txtId, txtStatus, txtTotal;

        VH(@NonNull View v) {
            super(v);
            txtId = v.findViewById(R.id.txtOrderId);
            txtStatus = v.findViewById(R.id.txtStatus);
            txtTotal = v.findViewById(R.id.txtTotal);
        }
    }
}
