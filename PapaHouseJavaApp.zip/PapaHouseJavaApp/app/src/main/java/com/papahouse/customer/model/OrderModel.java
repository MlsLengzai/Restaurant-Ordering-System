package com.papahouse.customer.model;

import java.util.List;

public class OrderModel {

    private String orderId;
    private List<CartItem> items;
    private double total;
    private String method;   // Pay at Counter / Card Payment
    private String status;   // e.g. Pending, Accepted, Completed
    private long timestamp;

    public OrderModel() {

    }

    public OrderModel(String orderId,
                      List<CartItem> items,
                      double total,
                      String method,
                      String status,
                      long timestamp) {
        this.orderId = orderId;
        this.items = items;
        this.total = total;
        this.method = method;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getOrderId() { return orderId; }
    public List<CartItem> getItems() { return items; }
    public double getTotal() { return total; }
    public String getMethod() { return method; }
    public String getStatus() { return status; }
    public long getTimestamp() { return timestamp; }
}
