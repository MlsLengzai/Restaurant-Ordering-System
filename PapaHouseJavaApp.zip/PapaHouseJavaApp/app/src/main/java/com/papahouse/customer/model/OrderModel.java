package com.papahouse.customer.model;

import java.util.List;

public class OrderModel {

    private String orderId;
    private List<CartItem> items;
    private double total;
    private String method;
    private String status;
    private long timestamp;

    public OrderModel() {}

    public OrderModel(String orderId, List<CartItem> items, double total,
                      String method, String status, long timestamp) {
        this.orderId = orderId;
        this.items = items;
        this.total = total;
        this.method = method;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getOrderId() { return orderId; }
    public List<CartItem> getItems() { return items; }
    public double getTotal() { return total; }
    public String getMethod() { return method; }
    public String getStatus() { return status; }
    public long getTimestamp() { return timestamp; }

    public void setOrderId(String orderId) { this.orderId = orderId; }
    public void setItems(List<CartItem> items) { this.items = items; }
    public void setTotal(double total) { this.total = total; }
    public void setMethod(String method) { this.method = method; }
    public void setStatus(String status) { this.status = status; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public int getProgressPercent() {
        if (status == null) return 0;
        switch (status) {
            case "Pending": return 20;
            case "Accepted": return 40;
            case "In Progress": return 60;
            case "Ready for Pickup": return 80;
            case "Completed": return 100;
            default: return 0;
        }
    }
}
