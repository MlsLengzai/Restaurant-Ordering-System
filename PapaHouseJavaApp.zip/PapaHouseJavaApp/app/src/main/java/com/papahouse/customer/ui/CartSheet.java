package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.button.MaterialButton;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartRepo;
import com.papahouse.customer.ui.adapter.CartAdapter;

public class CartSheet extends BottomSheetDialogFragment {

    private TextView txtTotal, txtEmpty, txtTakeaway;
    private CartAdapter adapter;
    private RecyclerView rvCart;
    private MaterialButton btnCheckout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.layout_cart_sheet, container, false);

        rvCart = v.findViewById(R.id.rvCart);
        txtTotal = v.findViewById(R.id.txtTotal);
        txtEmpty = v.findViewById(R.id.txtEmpty);
        txtTakeaway = v.findViewById(R.id.txtTakeaway);
        btnCheckout = v.findViewById(R.id.btnCheckout);

        adapter = new CartAdapter(CartRepo.get().items(), new CartAdapter.Listener() {
            @Override
            public void onPlus(int pos) {
                CartRepo.get().plus(pos);
                refresh();
            }

            @Override
            public void onMinus(int pos) {
                CartRepo.get().minus(pos);
                refresh();
            }
        });

        rvCart.setLayoutManager(new LinearLayoutManager(getContext()));
        rvCart.setAdapter(adapter);


        btnCheckout.setOnClickListener(view -> {
            if (CartRepo.get().items().isEmpty()) {
                Toast.makeText(getContext(),
                        "Please select your food or drink before checkout!",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            dismiss();
            Intent i = new Intent(getActivity(), PaymentActivity.class);
            startActivity(i);
        });

        refresh();
        return v;
    }

    private void refresh() {
        if (adapter != null) adapter.notifyDataSetChanged();

        double total = CartRepo.get().total();
        txtTotal.setText(String.format("Total: RM %.2f", total));


        if (CartRepo.get().isTakeaway()) {
            txtTakeaway.setVisibility(View.VISIBLE);
            txtTakeaway.setText(String.format("Takeaway Charge: RM %.2f", CartRepo.get().getTakeawayCharge()));
        } else {
            txtTakeaway.setVisibility(View.GONE);
        }

        // --- Keep checkout button enabled (we handle empty message ourselves) ---
        if (CartRepo.get().items().isEmpty()) {
            rvCart.setVisibility(View.GONE);
            txtEmpty.setVisibility(View.VISIBLE);
        } else {
            rvCart.setVisibility(View.VISIBLE);
            txtEmpty.setVisibility(View.GONE);
        }
    }
}
