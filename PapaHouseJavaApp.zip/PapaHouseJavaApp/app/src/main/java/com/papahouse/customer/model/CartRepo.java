package com.papahouse.customer.model;

import java.util.ArrayList;
import java.util.List;

public class CartRepo {
    private static final CartRepo INSTANCE = new CartRepo();
    public static CartRepo get() { return INSTANCE; }

    private final List<CartItem> cart = new ArrayList<>();

    private boolean isTakeaway = false;
    private double takeawayCharge = 0.0;

    public List<CartItem> items() { return cart; }

    public void add(MenuItemModel m) {
        for (CartItem c : cart) {
            if (c.item.id.equals(m.id)) {
                c.qty += 1;
                return;
            }
        }
        cart.add(new CartItem(m, 1));
    }

    public void plus(int pos) { cart.get(pos).qty++; }

    public void minus(int pos) {
        CartItem c = cart.get(pos);
        c.qty--;
        if (c.qty <= 0) cart.remove(pos);
    }

    public double total() {
        double t = 0;
        for (CartItem c : cart) t += c.lineTotal();
        if (isTakeaway) t += takeawayCharge;  // add RM 0.50 charge if takeaway
        return t;
    }

    public void clear() {
        cart.clear();
        isTakeaway = false;
        takeawayCharge = 0.0;
    }

    public void setTakeaway(boolean value) { this.isTakeaway = value; }
    public boolean isTakeaway() { return isTakeaway; }

    public void setTakeawayCharge(double charge) { this.takeawayCharge = charge; }
    public double getTakeawayCharge() { return takeawayCharge; }
}
