package com.papahouse.customer.ui.adapter;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartItem;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.VH> {

    public interface Listener {
        void onPlus(int pos);
        void onMinus(int pos);
    }

    private final List<CartItem> data;
    private final Listener listener;

    public CartAdapter(List<CartItem> data, Listener l) {
        this.data = data;
        this.listener = l;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cart, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        CartItem c = data.get(i);
        h.imgItem.setImageResource(c.item.imageRes);
        h.name.setText(c.item.name);
        h.qty.setText(String.valueOf(c.qty));
        h.line.setText(String.format("RM %.2f", c.lineTotal()));

        // ✅ remark handling
        h.remark.setText(c.remark);
        h.remark.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                c.remark = s.toString();
            }
        });

        h.minus.setOnClickListener(v -> listener.onMinus(h.getBindingAdapterPosition()));
        h.plus.setOnClickListener(v -> listener.onPlus(h.getBindingAdapterPosition()));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView imgItem;
        TextView name, qty, line;
        EditText remark;
        MaterialButton minus, plus;

        VH(View v) {
            super(v);
            imgItem = v.findViewById(R.id.imgItem);
            name = v.findViewById(R.id.txtCartName);
            qty = v.findViewById(R.id.txtQty);
            line = v.findViewById(R.id.txtLine);
            remark = v.findViewById(R.id.edtRemark);
            minus = v.findViewById(R.id.btnMinus);
            plus = v.findViewById(R.id.btnPlus);
        }
    }
}
