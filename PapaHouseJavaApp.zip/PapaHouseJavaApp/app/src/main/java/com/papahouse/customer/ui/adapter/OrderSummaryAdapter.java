package com.papahouse.customer.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.papahouse.customer.R;
import com.papahouse.customer.model.CartItem;

import java.util.List;

public class OrderSummaryAdapter extends RecyclerView.Adapter<OrderSummaryAdapter.VH> {

    private final List<CartItem> items;

    public OrderSummaryAdapter(List<CartItem> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_summary, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int i) {
        CartItem c = items.get(i);
        String text = c.item.name + " (" + c.item.id + ") x" + c.qty;
        h.txtName.setText(text);

        if (c.remark != null && !c.remark.trim().isEmpty()) {
            h.txtRemark.setVisibility(View.VISIBLE);
            h.txtRemark.setText("Remark: " + c.remark);
        } else {
            h.txtRemark.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView txtName, txtRemark;
        VH(View v) {
            super(v);
            txtName = v.findViewById(R.id.txtItemName);
            txtRemark = v.findViewById(R.id.txtItemRemark);
        }
    }
}
