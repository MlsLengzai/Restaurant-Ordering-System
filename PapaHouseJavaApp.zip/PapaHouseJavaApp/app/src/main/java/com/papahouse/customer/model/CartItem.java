package com.papahouse.customer.model;

public class CartItem {

    public MenuItemModel item;
    public int qty;
    public String remark = "";
    public String drinkType = "";

    public CartItem() {
    }

    public CartItem(MenuItemModel item, int qty) {
        this.item = item;
        this.qty = qty;
    }

    public double lineTotal() {
        return qty * item.price;
    }

    public MenuItemModel getItem() { return item; }
    public int getQty() { return qty; }
    public String getRemark() { return remark; }
    public String getDrinkType() { return drinkType; }
}
