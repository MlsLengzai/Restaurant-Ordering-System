package com.papahouse.customer.ui;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.papahouse.customer.R;

public class OrderTrackingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_order_tracking);

        TextView txtOrderId = findViewById(R.id.txtOrderId);
        TextView txtStatus = findViewById(R.id.txtStatus);
        ProgressBar progress = findViewById(R.id.progressBar);

        String orderId = getIntent().getStringExtra("orderId");
        txtOrderId.setText("Order #" + orderId);

        FirebaseFirestore.getInstance()
                .collection("orders")
                .document(orderId)
                .addSnapshotListener((doc, e) -> {
                    if (doc == null || !doc.exists()) return;

                    String status = doc.getString("status");
                    if (status == null) status = "Pending";

                    txtStatus.setText(status);

                    int percent;
                    switch (status) {
                        case "Pending": percent = 20; break;
                        case "Accepted": percent = 40; break;
                        case "In Progress": percent = 60; break;
                        case "Ready for Pickup": percent = 80; break;
                        case "Completed": percent = 100; break;
                        default: percent = 0;
                    }
                    progress.setProgress(percent);
                });
    }
}
