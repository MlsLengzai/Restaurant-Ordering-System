package com.papahouse.customer.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.papahouse.customer.R;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public class OrderTrackingActivity extends AppCompatActivity {

    private TextView txtStatus, txtOrderId, txtItemsSummary;
    private ImageView ivStatusGif;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private String orderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        db = FirebaseFirestore.getInstance();

        orderId = getIntent().getStringExtra("orderId");
        if (orderId == null) {
            Toast.makeText(this, "Order not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupToolbar();
        initViews();

        txtOrderId.setText("Order #" + orderId.substring(0, 6).toUpperCase());

        trackOrder();
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.trackingToolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initViews() {
        txtStatus = findViewById(R.id.txtTrackingStatus);
        txtOrderId = findViewById(R.id.txtOrderId);
        txtItemsSummary = findViewById(R.id.txtItemsSummary);
        ivStatusGif = findViewById(R.id.ivStatusGif);
        progressBar = findViewById(R.id.progressBarTracking);
    }

    private void trackOrder() {
        db.collection("orders")
                .document(orderId)
                .addSnapshotListener((snap, e) -> {
                    if (e != null) {
                        Log.e("OrderTracking", "Error", e);
                        return;
                    }
                    if (snap != null && snap.exists()) {
                        updateUI(snap);
                    }
                });
    }

    private void updateUI(DocumentSnapshot snap) {
        progressBar.setVisibility(View.GONE);


        String status = snap.getString("status");
        if (status == null) status = "Processing";
        txtStatus.setText(status);

        Glide.with(this)
                .asGif()
                .load(R.drawable.anim_delivery)
                .into(ivStatusGif);


        StringBuilder summary = new StringBuilder();
        Object itemsObj = snap.get("items");

        if (itemsObj instanceof List) {
            List<Map<String, Object>> items = (List<Map<String, Object>>) itemsObj;

            for (Map<String, Object> cartItem : items) {

                long qty = 1;
                Object q = cartItem.get("qty");
                if (q instanceof Number) qty = ((Number) q).longValue();

                String name = "Unknown Item";
                double price = 0;

                Object itemObj = cartItem.get("item");
                if (itemObj instanceof Map) {
                    Map<String, Object> menuItem = (Map<String, Object>) itemObj;

                    if (menuItem.get("name") != null)
                        name = menuItem.get("name").toString();

                    if (menuItem.get("price") instanceof Number)
                        price = ((Number) menuItem.get("price")).doubleValue();
                }

                summary.append(qty)
                        .append("x ")
                        .append(name);

                if (price > 0) {
                    summary.append("  (RM ")
                            .append(String.format(Locale.getDefault(), "%.2f", price * qty))
                            .append(")");
                }

                summary.append("\n");
            }
        } else {
            summary.append("No items found.");
        }

        // --- TOTAL ---
        Double total = snap.getDouble("total");
        summary.append("\n-----------------------------\n");
        summary.append("Total Amount: RM ")
                .append(String.format(Locale.getDefault(), "%.2f", total != null ? total : 0));

        txtItemsSummary.setText(summary.toString());
    }
}
