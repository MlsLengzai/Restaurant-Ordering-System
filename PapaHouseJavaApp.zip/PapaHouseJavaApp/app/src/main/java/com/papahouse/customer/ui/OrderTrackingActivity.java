package com.papahouse.customer.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.papahouse.customer.R;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public class OrderTrackingActivity extends AppCompatActivity {

    private TextView txtStatus, txtOrderId, txtItemsSummary;
    private ImageView ivStatusGif;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private String orderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        db = FirebaseFirestore.getInstance();
        orderId = getIntent().getStringExtra("orderId");

        setupToolbar();
        initViews();

        if (orderId == null) {
            Toast.makeText(this, "Error: No Order ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        txtOrderId.setText("Order #" + orderId.substring(0, Math.min(orderId.length(), 8)).toUpperCase());
        startTracking();
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.trackingToolbar);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initViews() {
        txtStatus = findViewById(R.id.txtTrackingStatus);
        txtOrderId = findViewById(R.id.txtOrderId);
        txtItemsSummary = findViewById(R.id.txtItemsSummary);
        ivStatusGif = findViewById(R.id.ivStatusGif);
        progressBar = findViewById(R.id.progressBarTracking);
    }

    private void startTracking() {
        db.collection("orders").document(orderId)
                .addSnapshotListener((snapshot, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Listen failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);
                        return;
                    }

                    if (snapshot != null && snapshot.exists()) {
                        updateUI(snapshot);
                    } else {
                        txtStatus.setText("Order not found.");
                        progressBar.setVisibility(View.GONE);
                    }
                });
    }

    private void updateUI(DocumentSnapshot snap) {
        progressBar.setVisibility(View.GONE);
        String status = snap.getString("status");
        Double total = snap.getDouble("total");

        if (status == null) status = "Unknown";

        txtStatus.setText(status);

        // ✅ FIXED: Use your uploaded "anim_delivery" gif for all active states
        // You can add more GIFs later for different states if you want.
        int gifResource = R.drawable.anim_delivery;

        Glide.with(this)
                .asGif()
                .load(gifResource)
                .into(ivStatusGif);

        List<Map<String, Object>> itemsMap = (List<Map<String, Object>>) snap.get("items");
        if (itemsMap != null) {
            StringBuilder summary = new StringBuilder();
            for (Map<String, Object> item : itemsMap) {
                String name = (String) item.get("name");
                long qty = ((Number) item.get("quantity")).longValue();
                summary.append("• ").append(qty).append("x ").append(name).append("\n");
            }
            summary.append("\nTotal: RM ").append(String.format(Locale.getDefault(), "%.2f", total));
            txtItemsSummary.setText(summary.toString());
        }
    }
}