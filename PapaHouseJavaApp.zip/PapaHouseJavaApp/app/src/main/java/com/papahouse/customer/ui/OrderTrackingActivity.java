package com.papahouse.customer.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.papahouse.customer.R;

import java.util.List;
import java.util.Locale;
import java.util.Map;

public class OrderTrackingActivity extends AppCompatActivity {

    private TextView txtStatus, txtOrderId, txtItemsSummary;
    private ImageView ivStatusGif;
    private ProgressBar progressBar;
    private FirebaseFirestore db;
    private String orderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_tracking);

        db = FirebaseFirestore.getInstance();

        if (getIntent() != null) {
            orderId = getIntent().getStringExtra("orderId");
        }

        setupToolbar();
        initViews();

        if (orderId == null) {
            Toast.makeText(this, "Error: Order ID is missing", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String displayId = (orderId.length() >= 8) ? orderId.substring(0, 8).toUpperCase() : orderId.toUpperCase();
        txtOrderId.setText("Order #" + displayId);

        startTracking();
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.trackingToolbar);
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(v -> finish());
        }
    }

    private void initViews() {
        txtStatus = findViewById(R.id.txtTrackingStatus);
        txtOrderId = findViewById(R.id.txtOrderId);
        txtItemsSummary = findViewById(R.id.txtItemsSummary);
        ivStatusGif = findViewById(R.id.ivStatusGif);
        progressBar = findViewById(R.id.progressBarTracking);
    }

    private void startTracking() {
        db.collection("orders").document(orderId)
                .addSnapshotListener((snapshot, e) -> {
                    if (e != null) return;
                    if (snapshot != null && snapshot.exists()) {
                        updateUI(snapshot);
                    } else {
                        if (txtStatus != null) txtStatus.setText("Order not found.");
                    }
                });
    }

    private void updateUI(DocumentSnapshot snap) {
        if (progressBar != null) progressBar.setVisibility(View.GONE);

        // 1. Update Status
        String status = snap.getString("status");
        if (status == null) status = "Processing";
        if (txtStatus != null) txtStatus.setText(status);

        // 2. Load GIF
        if (ivStatusGif != null) {
            Glide.with(this).asGif().load(R.drawable.anim_delivery).into(ivStatusGif);
        }

        // 3. READ FOOD LIST (Smart & Detailed)
        if (txtItemsSummary != null) {
            StringBuilder summary = new StringBuilder();

            Object itemsObj = snap.get("items");
            if (itemsObj instanceof List) {
                List<Map<String, Object>> itemsMap = (List<Map<String, Object>>) itemsObj;

                if (itemsMap.isEmpty()) {
                    summary.append("No items in order.");
                } else {
                    for (Map<String, Object> item : itemsMap) {

                        // --- STEP A: FIND THE NAME (Deep Search) ---
                        String name = (String) item.get("name");

                        // If null, check if it's nested inside "food" or "product"
                        if (name == null && item.get("food") instanceof Map) {
                            name = (String) ((Map) item.get("food")).get("name");
                        }
                        if (name == null && item.get("product") instanceof Map) {
                            name = (String) ((Map) item.get("product")).get("name");
                        }
                        // Fallback keys
                        if (name == null) name = (String) item.get("foodName");
                        if (name == null) name = "Unknown Item";

                        // --- STEP B: FIND QUANTITY ---
                        long qty = 1;
                        Object qObj = item.get("quantity");
                        if (qObj == null) qObj = item.get("qty");
                        if (qObj instanceof Number) qty = ((Number) qObj).longValue();

                        // --- STEP C: FIND PRICE (Optional) ---
                        double price = 0.0;
                        Object pObj = item.get("price");
                        // Check nested price too
                        if (pObj == null && item.get("food") instanceof Map) {
                            pObj = ((Map) item.get("food")).get("price");
                        }
                        if (pObj instanceof Number) price = ((Number) pObj).doubleValue();

                        // --- FORMAT: 2x Burger ..... RM 24.00 ---
                        summary.append(qty).append("x  ").append(name);
                        if (price > 0) {
                            summary.append("  (RM ").append(String.format(Locale.getDefault(), "%.2f", price * qty)).append(")");
                        }
                        summary.append("\n");
                    }
                }
            } else {
                summary.append("Order details are empty.");
            }

            Double total = snap.getDouble("total");
            summary.append("\n--------------------------------------\n");
            if (total != null) {
                summary.append("Total Amount:     RM ").append(String.format(Locale.getDefault(), "%.2f", total));
            } else {
                summary.append("Total Amount:     RM 0.00");
            }

            txtItemsSummary.setText(summary.toString());
        }
    }
}