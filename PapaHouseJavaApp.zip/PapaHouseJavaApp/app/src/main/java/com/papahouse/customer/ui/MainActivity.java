package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartRepo;
import com.papahouse.customer.model.MenuItemModel;
import com.papahouse.customer.ui.adapter.MenuAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private final List<MenuItemModel> all = new ArrayList<>();
    private MenuAdapter adapter;
    private ExtendedFloatingActionButton fabCart;

    private static List<String> cats() {
        return Arrays.asList("All", "Burgers", "Breakfast", "Sides", "Pasta", "Pizza", "Drinks");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        toolbar.setNavigationOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DineInTakeawayActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });

        seed();

        RecyclerView rv = findViewById(R.id.rvMenu);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new MenuAdapter(m -> {
            CartRepo.get().add(m);
            updateCartCount();
            new CartSheet().show(getSupportFragmentManager(), "cart");
        });
        rv.setAdapter(adapter);

        ChipGroup chipGroup = findViewById(R.id.chips);
        for (String c : cats()) {
            Chip chip = new Chip(this);
            chip.setText(c);
            chip.setCheckable(true);
            if (c.equals("All")) chip.setChecked(true);
            chipGroup.addView(chip);
        }
        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> filter());

        EditText edt = findViewById(R.id.edtSearch);
        edt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filter(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        fabCart = findViewById(R.id.fabCart);
        fabCart.setOnClickListener(v -> new CartSheet().show(getSupportFragmentManager(), "cart"));


        FloatingActionButton fabAi = findViewById(R.id.fabAi);
        setupDraggableAiButton(fabAi);

        filter();
        updateCartCount();
    }

    private void setupDraggableAiButton(FloatingActionButton fabAi) {
        fabAi.setOnTouchListener(new View.OnTouchListener() {
            float dX, dY;
            boolean isMoving = false;
            long touchStartTime;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        touchStartTime = System.currentTimeMillis();
                        dX = view.getX() - event.getRawX();
                        dY = view.getY() - event.getRawY();
                        isMoving = false;
                        break;

                    case MotionEvent.ACTION_MOVE:
                        float newX = event.getRawX() + dX;
                        float newY = event.getRawY() + dY;
                        view.animate().x(newX).y(newY).setDuration(0).start();
                        isMoving = true;
                        break;

                    case MotionEvent.ACTION_UP:
                        long pressDuration = System.currentTimeMillis() - touchStartTime;
                        if (!isMoving || pressDuration < 150) {

                            new com.papahouse.customer.ui.ai.PapaAiDialog()
                                    .show(getSupportFragmentManager(), "papa_ai");
                        }
                        break;
                }
                return true;
            }
        });
    }

    private void updateCartCount() {
        int count = 0;
        for (var c : CartRepo.get().items()) count += c.qty;
        fabCart.setText("Cart (" + count + ")");
    }

    private void filter() {
        ChipGroup chips = findViewById(R.id.chips);
        String cat = "All";
        if (chips.getCheckedChipIds().size() > 0) {
            Chip selected = chips.findViewById(chips.getCheckedChipIds().get(0));
            if (selected != null) cat = selected.getText().toString();
        }

        String q = ((EditText) findViewById(R.id.edtSearch))
                .getText().toString().trim().toLowerCase();

        List<MenuItemModel> out = new ArrayList<>();
        for (MenuItemModel m : all) {
            boolean matchCat = cat.equals("All") || m.category.equalsIgnoreCase(cat);
            boolean matchQuery = m.name.toLowerCase().contains(q)
                    || m.id.toLowerCase().contains(q)
                    || m.category.toLowerCase().contains(q);
            if (matchCat && (q.isEmpty() || matchQuery)) out.add(m);
        }

        adapter.submit(out);
    }

    private void seed() {
        all.clear();

        // Burgers
        all.add(new MenuItemModel("B1", "Signature Burger", 16.9, R.drawable.burger, "Burgers"));
        all.add(new MenuItemModel("B2", "Cheeseburger", 19.9, R.drawable.doublecheeseburger, "Burgers"));
        // Breakfast
        all.add(new MenuItemModel("BF1", "Big Breakfast", 21.5, R.drawable.bigbreakfast, "Breakfast"));
        all.add(new MenuItemModel("BF2", "Toast", 14.0, R.drawable.avocadotoast, "Breakfast"));
        // Sides
        all.add(new MenuItemModel("F1", "Crispy Fries", 8.5, R.drawable.fries, "Sides"));
        // Pasta
        all.add(new MenuItemModel("P1", "Carbonara", 18.0, R.drawable.carbonara, "Pasta"));
        all.add(new MenuItemModel("P2", "Aglio Olio", 16.5, R.drawable.aglioolio, "Pasta"));
        all.add(new MenuItemModel("P3", "Bolognese", 17.5, R.drawable.bolognese, "Pasta"));
        // Pizza
        all.add(new MenuItemModel("Z1", "Margherita Pizza", 22.0, R.drawable.margherita, "Pizza"));
        all.add(new MenuItemModel("Z2", "Pepperoni Pizza", 24.0, R.drawable.pepperoni, "Pizza"));
        all.add(new MenuItemModel("Z3", "Hawaiian Pizza", 23.0, R.drawable.hawaiian, "Pizza"));
        // Drinks
        all.add(new MenuItemModel("D1", "Iced Lemon Tea", 6.5, R.drawable.icelemontea, "Drinks"));
        all.add(new MenuItemModel("D2", "Coffee Latte", 8.0, R.drawable.coffeelatte, "Drinks"));
        all.add(new MenuItemModel("D3", "Cappuccino", 8.5, R.drawable.cappuccino, "Drinks"));
        all.add(new MenuItemModel("D4", "Matcha Latte", 9.0, R.drawable.matchalatte, "Drinks"));
        all.add(new MenuItemModel("D5", "Coco-Milkshake", 9.5, R.drawable.chocolatemilkshake, "Drinks"));
    }
}
