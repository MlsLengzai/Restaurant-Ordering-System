package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.papahouse.customer.R;

public class DineInTakeawayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dinein_takeaway);

        Button btnDineIn = findViewById(R.id.btnDineIn);
        Button btnTakeaway = findViewById(R.id.btnTakeaway);

        btnDineIn.setOnClickListener(v -> openMenu());
        btnTakeaway.setOnClickListener(v -> openMenu());
    }

    private void openMenu() {
        Intent intent = new Intent(DineInTakeawayActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
