package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartRepo;

public class DineInTakeawayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dinein_takeaway);

        // 1. Setup Toolbar Back Button
        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        toolbar.setNavigationOnClickListener(v -> finish());

        // 2. Animate the Logo
        ImageView imgLogo = findViewById(R.id.imgLogo);
        Animation slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_in_up);
        imgLogo.startAnimation(slideUp);

        // 3. Handle Card Clicks
        View btnDineIn = findViewById(R.id.cardDineIn);
        View btnTakeaway = findViewById(R.id.cardTakeaway);

        btnDineIn.setOnClickListener(v -> {
            CartRepo.get().setTakeaway(false);
            Toast.makeText(this, "Dine-in selected", Toast.LENGTH_SHORT).show();
            openMenu();
        });

        btnTakeaway.setOnClickListener(v -> {
            CartRepo.get().setTakeaway(true);
            CartRepo.get().setTakeawayCharge(0.50);
            Toast.makeText(this, "Takeaway selected (+RM0.50 charge)", Toast.LENGTH_SHORT).show();
            openMenu();
        });
    }

    private void openMenu() {
        Intent intent = new Intent(DineInTakeawayActivity.this, MainActivity.class);
        startActivity(intent);

    }
}