package com.papahouse.customer.ui.ai;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.button.MaterialButton;
import com.papahouse.customer.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PapaAiDialog extends DialogFragment {

    private EditText edtInput;
    private TextView txtResponse;
    private MaterialButton btnSend;
    private ImageButton btnMic;
    private SpeechRecognizer speechRecognizer;

    // Gemini
    private static final String GEMINI_API_KEY = "AIzaSyCGZh55T5hj7plNAkvSecRuNCY3tVuAa-k";
    private static final String GEMINI_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + GEMINI_API_KEY;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_papa_ai, container, false);

        edtInput = view.findViewById(R.id.edtInput);
        txtResponse = view.findViewById(R.id.txtResponse);
        btnSend = view.findViewById(R.id.btnSend);
        btnMic = view.findViewById(R.id.btnMic);

        // 🎙️ Setup Speech Recognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(requireContext());
        btnMic.setOnClickListener(v -> startVoiceInput());

        btnSend.setOnClickListener(v -> {
            String userText = edtInput.getText().toString().trim();
            if (!TextUtils.isEmpty(userText)) {
                simulateAiThinking(userText);
                edtInput.setText("");
            }
        });

        view.setOnClickListener(v -> dismiss());
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    // 🎤 Voice recognition logic
    private void startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(requireContext())) {
            Toast.makeText(requireContext(), "Voice recognition not supported on this device", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Tell me how you feel...");

        speechRecognizer.startListening(intent);
        speechRecognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                Toast.makeText(requireContext(), "Could not recognize speech, try again.", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String spokenText = matches.get(0);
                    edtInput.setText(spokenText);
                    simulateAiThinking(spokenText);
                }
            }

            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void simulateAiThinking(String input) {
        txtResponse.setText("Papa AI is thinking… 🤔");
        new Handler().postDelayed(() -> new Thread(() -> {
            String reply = getAiReplyFromGemini(input);
            if (reply == null || reply.isEmpty()) reply = getOfflineSuggestion(input);
            final String finalReply = reply;
            requireActivity().runOnUiThread(() -> txtResponse.setText(finalReply));
        }).start(), 800);
    }

    private String getAiReplyFromGemini(String userMessage) {
        OkHttpClient client = new OkHttpClient();
        try {
            JSONObject textPart = new JSONObject();
            textPart.put("text", "You are Papa AI, a friendly restaurant assistant. "
                    + "Respond briefly with food/drink suggestions for this feeling: " + userMessage);

            JSONArray parts = new JSONArray().put(textPart);
            JSONObject message = new JSONObject().put("parts", parts);
            JSONArray contents = new JSONArray().put(message);
            JSONObject jsonBody = new JSONObject().put("contents", contents);

            RequestBody body = RequestBody.create(jsonBody.toString(), MediaType.parse("application/json"));
            Request request = new Request.Builder().url(GEMINI_URL).post(body).build();
            Response response = client.newCall(request).execute();

            if (response.isSuccessful() && response.body() != null) {
                String resStr = response.body().string();
                JSONObject json = new JSONObject(resStr);
                JSONArray candidates = json.getJSONArray("candidates");
                JSONObject content = candidates.getJSONObject(0).getJSONObject("content");
                JSONArray partsArr = content.getJSONArray("parts");
                return partsArr.getJSONObject(0).getString("text").trim();
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getOfflineSuggestion(String input) {
        input = input.toLowerCase();

        if (input.contains("tired") || input.contains("sleepy"))
            return "You seem tired 😴. A warm Coffee Latte or Matcha Latte might help you recharge!";
        if (input.contains("angry") || input.contains("mad"))
            return "Feeling angry 😡? Try some Crispy Fries and an Iced Lemon Tea to cool down.";
        if (input.contains("sad"))
            return "Cheer up 💪! A Big Breakfast and a creamy Coco-Milkshake might lift your mood!";
        if (input.contains("cold") || input.contains("rain"))
            return "It’s cold 🥶 — a hot Cappuccino or Carbonara Pasta will warm you right up!";
        if (input.contains("hot"))
            return "It’s hot outside 🌞 — cool off with our Iced Lemon Tea or Coco-Milkshake!";
        if (input.contains("hungry"))
            return "Hungry? 🍔 Go for our Signature Burger or Bolognese Pasta!";
        if (input.contains("study") || input.contains("focus"))
            return "Need focus 🎓? A Coffee Latte and Crispy Fries combo will boost your energy!";
        if (input.contains("stress") || input.contains("stressed") || input.contains("annoy") || input.contains("annoyed"))
            return "Take a break 😌. Relax with a smooth Matcha Latte or a sweet Coco-Milkshake!";
        if (input.contains("happy") || input.contains("excited"))
            return "Nice! 🎉 Celebrate with a Signature Burger and a Coco-Milkshake!";
        return "Hmm 🤔 Maybe try our Chef’s Recommendation — the Pepperoni Pizza!";
    }
}
