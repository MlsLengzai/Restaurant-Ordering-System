package com.papahouse.customer.ui.util;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;

public class DeviceIdManager {
    private static final String PREF_NAME = "app_prefs";
    private static final String KEY_DEVICE_ID = "device_id";

    public static String get(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String id = prefs.getString(KEY_DEVICE_ID, null);

        if (id == null) {
            // Generate a new unique ID and save it permanently
            id = UUID.randomUUID().toString();
            prefs.edit().putString(KEY_DEVICE_ID, id).apply();
        }
        return id;
    }
}