package com.papahouse.customer.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartRepo;

public class HomeActivity extends AppCompatActivity {

    private static final double TAKEAWAY_CHARGE = 0.50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        MaterialButton btnDineIn = findViewById(R.id.btnDineIn);
        MaterialButton btnTakeaway = findViewById(R.id.btnTakeaway);

        // Dine-in button — no extra charge
        btnDineIn.setOnClickListener(v -> {
            CartRepo.get().setTakeaway(false);
            Toast.makeText(this, "Dine-in selected", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
        });

        // Takeaway button — add RM0.50 service fee
        btnTakeaway.setOnClickListener(v -> {
            CartRepo.get().setTakeaway(true);
            CartRepo.get().setTakeawayCharge(TAKEAWAY_CHARGE);
            Toast.makeText(this, "Takeaway selected (+RM0.50 charge)", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
        });
    }
}
