package com.papahouse.customer.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartItem;
import com.papahouse.customer.model.CartRepo;
import com.papahouse.customer.ui.adapter.OrderSummaryAdapter;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PaymentActivity extends AppCompatActivity {

    private TextView txtGrand;
    private RadioGroup rg;
    private RadioButton rbCounter, rbCard;
    private View sectionCard;
    private EditText edtCard, edtName, edtExpiry, edtCvv;

    private TextView txtCardNumberPreview, txtCardNamePreview, txtCardExpiryPreview, txtCardCvvPreview;
    private RecyclerView rvOrderItems;

    private AlertDialog loadingDialog;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        db = FirebaseFirestore.getInstance();

        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        if (toolbar != null) toolbar.setNavigationOnClickListener(v -> onBackPressed());

        rvOrderItems = findViewById(R.id.rvOrderItems);
        rvOrderItems.setLayoutManager(new LinearLayoutManager(this));
        rvOrderItems.setAdapter(new OrderSummaryAdapter(CartRepo.get().items()));

        txtGrand = findViewById(R.id.txtGrand);
        rg = findViewById(R.id.rgMethod);
        rbCounter = findViewById(R.id.rbCounter);
        rbCard = findViewById(R.id.rbCard);
        sectionCard = findViewById(R.id.sectionCard);
        edtCard = findViewById(R.id.edtCard);
        edtName = findViewById(R.id.edtName);
        edtExpiry = findViewById(R.id.edtExpiry);
        edtCvv = findViewById(R.id.edtCvv);

        txtCardNumberPreview = findViewById(R.id.txtCardNumberPreview);
        txtCardNamePreview = findViewById(R.id.txtCardNamePreview);
        txtCardExpiryPreview = findViewById(R.id.txtCardExpiryPreview);
        txtCardCvvPreview = findViewById(R.id.txtCardCvvPreview);

        double total = CartRepo.get().total();
        txtGrand.setText(String.format(Locale.getDefault(), "Total: RM %.2f", total));

        rg.setOnCheckedChangeListener((group, checkedId) -> {
            sectionCard.setVisibility(checkedId == R.id.rbCard ? View.VISIBLE : View.GONE);
        });
        rbCounter.setChecked(true);

        MaterialButton btnPay = findViewById(R.id.btnPay);
        btnPay.setOnClickListener(v -> handlePay(total));
    }

    private void handlePay(double total) {

        if (CartRepo.get().items().isEmpty()) {
            Toast.makeText(this, "Please select items first!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (rbCounter.isChecked()) {
            saveOrderToFirestore(total, "Pay at Counter");
            openReceipt("Pay at Counter");
            return;
        }

        if (edtCard.getText().toString().replaceAll("[^0-9]", "").length() < 16) {
            edtCard.setError("Enter 16-digit card");
            return;
        }
        if (edtExpiry.getText().toString().length() < 4) {
            edtExpiry.setError("Invalid expiry");
            return;
        }
        if (edtCvv.getText().toString().length() < 3) {
            edtCvv.setError("Invalid CVV");
            return;
        }
        if (edtName.getText().toString().trim().isEmpty()) {
            edtName.setError("Enter name");
            return;
        }

        showLoadingDialog();

        new Handler().postDelayed(() -> {
            dismissLoadingDialog();
            saveOrderToFirestore(total, "Card Payment");
            openReceipt("Card Payment");
        }, 2000);
    }

    private void saveOrderToFirestore(double total, String method) {

        String orderId = db.collection("orders").document().getId();

        List<CartItem> items = CartRepo.get().items();

        Map<String, Object> order = new HashMap<>();
        order.put("orderId", orderId);
        order.put("method", method);
        order.put("total", total);
        order.put("status", "Pending");
        order.put("timestamp", System.currentTimeMillis());
        order.put("items", items);

        db.collection("orders")
                .document(orderId)
                .set(order)
                .addOnSuccessListener(unused ->
                        Toast.makeText(this, "Order sent to Firestore!", Toast.LENGTH_SHORT).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
    }

    private void openReceipt(String method) {
        Intent i = new Intent(this, ReceiptActivity.class);
        i.putExtra("method", method);
        startActivity(i);
        finish();
    }

    private void showLoadingDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_loading, null);
        loadingDialog = new AlertDialog.Builder(this)
                .setView(view)
                .setCancelable(false)
                .create();
        loadingDialog.show();
    }

    private void dismissLoadingDialog() {
        if (loadingDialog != null && loadingDialog.isShowing())
            loadingDialog.dismiss();
    }

    private abstract static class SimpleWatcher implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }
}
