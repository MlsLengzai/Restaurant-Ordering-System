package com.papahouse.customer.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.papahouse.customer.R;
import com.papahouse.customer.model.CartItem;
import com.papahouse.customer.model.CartRepo;
import com.papahouse.customer.ui.adapter.OrderSummaryAdapter;
import com.papahouse.customer.ui.util.DeviceIdManager;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PaymentActivity extends AppCompatActivity {

    private TextView txtGrand;
    private RadioGroup rg;
    private RadioButton rbCounter, rbCard;

    private View sectionCard;
    private View cardPreviewWrap;

    // Input Fields
    private EditText edtCard, edtName, edtExpiry, edtCvv;

    private TextView txtCardNumberPreview, txtCardNamePreview, txtCardExpiryPreview, txtCardCvvPreview;

    private RecyclerView rvOrderItems;
    private AlertDialog loadingDialog;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        db = FirebaseFirestore.getInstance();

        MaterialToolbar toolbar = findViewById(R.id.topAppBar);
        if (toolbar != null) toolbar.setNavigationOnClickListener(v -> finish());

        rvOrderItems = findViewById(R.id.rvOrderItems);
        rvOrderItems.setLayoutManager(new LinearLayoutManager(this));
        rvOrderItems.setAdapter(new OrderSummaryAdapter(CartRepo.get().items()));

        // Initialize Views
        txtGrand = findViewById(R.id.txtGrand);
        rg = findViewById(R.id.rgMethod);
        rbCounter = findViewById(R.id.rbCounter);
        rbCard = findViewById(R.id.rbCard);

        // Containers
        sectionCard = findViewById(R.id.sectionCard);
        cardPreviewWrap = findViewById(R.id.cardPreviewWrap);

        // Inputs
        edtCard = findViewById(R.id.edtCard);
        edtName = findViewById(R.id.edtName);
        edtExpiry = findViewById(R.id.edtExpiry);
        edtCvv = findViewById(R.id.edtCvv);

        // Previews
        txtCardNumberPreview = findViewById(R.id.txtCardNumberPreview);
        txtCardNamePreview = findViewById(R.id.txtCardNamePreview);
        txtCardExpiryPreview = findViewById(R.id.txtCardExpiryPreview);
        txtCardCvvPreview = findViewById(R.id.txtCardCvvPreview);

        double total = CartRepo.get().total();
        txtGrand.setText(String.format(Locale.getDefault(), "Total: RM %.2f", total));

        // Logic
        rg.setOnCheckedChangeListener((group, checkedId) -> {
            boolean isCard = (checkedId == R.id.rbCard);
            sectionCard.setVisibility(isCard ? View.VISIBLE : View.GONE);
            cardPreviewWrap.setVisibility(isCard ? View.VISIBLE : View.GONE);
        });

        rbCounter.setChecked(true);
        sectionCard.setVisibility(View.GONE);
        cardPreviewWrap.setVisibility(View.GONE);



        edtName.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString().trim();
                txtCardNamePreview.setText(text.isEmpty() ? "CARDHOLDER NAME" : text.toUpperCase());
            }
        });

        // Card Number
        edtCard.addTextChangedListener(new TextWatcher() {
            private static final char SPACE_CHAR = ' ';

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {

                if (s.toString().length() > 0 && (s.toString().length() % 5) == 0 && s.charAt(s.length() - 1) == SPACE_CHAR) {
                    return;
                }


                String initial = s.toString().replaceAll(" ", "");
                StringBuilder formatted = new StringBuilder();

                // Add space every 4 digits
                for (int i = 0; i < initial.length(); i++) {
                    if (i > 0 && i % 4 == 0) {
                        formatted.append(" ");
                    }
                    formatted.append(initial.charAt(i));
                }


                edtCard.removeTextChangedListener(this);
                edtCard.setText(formatted.toString());
                edtCard.setSelection(formatted.length()); // Move cursor to end
                edtCard.addTextChangedListener(this);


                String previewText = formatted.toString();
                txtCardNumberPreview.setText(previewText.isEmpty() ? "**** **** **** ****" : previewText);
            }
        });

        // Expiry
        edtExpiry.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString().trim();

                if (text.length() == 2 && before == 0) {
                    text += "/";
                    edtExpiry.setText(text);
                    edtExpiry.setSelection(text.length());
                }
                txtCardExpiryPreview.setText(text.isEmpty() ? "MM/YY" : text);
            }
        });

        // CVV
        edtCvv.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String text = s.toString().trim();
                txtCardCvvPreview.setText(text.isEmpty() ? "CVV" : text);
            }
        });

        MaterialButton btnPay = findViewById(R.id.btnPay);
        btnPay.setOnClickListener(v -> handlePay(total));
    }

    private void handlePay(double total) {
        if (CartRepo.get().items().isEmpty()) {
            Toast.makeText(this, "Please select items first!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (rbCounter.isChecked()) {
            saveOrderToFirestore(total, "Pay at Counter");
            openReceipt("Pay at Counter");
            return;
        }


        String rawCard = edtCard.getText().toString().replace(" ", "");
        if (rawCard.length() != 16) {
            edtCard.setError("Invalid card number (16 digits required)");
            return;
        }
        if (edtExpiry.getText().toString().length() < 5) { // MM/YY is 5 chars
            edtExpiry.setError("Invalid expiry (MM/YY)");
            return;
        }
        if (edtCvv.getText().toString().length() < 3) {
            edtCvv.setError("Invalid CVV");
            return;
        }
        if (edtName.getText().toString().trim().isEmpty()) {
            edtName.setError("Enter name");
            return;
        }

        showLoadingDialog();
        new Handler().postDelayed(() -> {
            dismissLoadingDialog();
            saveOrderToFirestore(total, "Card Payment");
            openReceipt("Card Payment");
        }, 2000);
    }

    private void saveOrderToFirestore(double total, String method) {
        String orderId = db.collection("orders").document().getId();
        List<CartItem> items = CartRepo.get().items();
        String customerId = DeviceIdManager.get(this);

        Map<String, Object> order = new HashMap<>();
        order.put("orderId", orderId);
        order.put("customerId", customerId);
        order.put("method", method);
        order.put("total", total);
        order.put("status", "Pending");
        order.put("timestamp", System.currentTimeMillis());
        order.put("items", items);

        db.collection("orders").document(orderId).set(order)
                .addOnSuccessListener(unused -> Toast.makeText(this, "Order sent!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void openReceipt(String method) {
        Intent i = new Intent(this, ReceiptActivity.class);
        i.putExtra("method", method);
        startActivity(i);
        finish();
    }

    private void showLoadingDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_loading, null);
        loadingDialog = new AlertDialog.Builder(this).setView(view).setCancelable(false).create();
        loadingDialog.show();
    }

    private void dismissLoadingDialog() {
        if (loadingDialog != null && loadingDialog.isShowing()) loadingDialog.dismiss();
    }

    public abstract class SimpleTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void afterTextChanged(Editable s) {}
    }
}