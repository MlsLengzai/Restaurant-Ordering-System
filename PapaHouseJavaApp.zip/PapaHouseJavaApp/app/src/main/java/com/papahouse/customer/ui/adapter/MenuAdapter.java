package com.papahouse.customer.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.papahouse.customer.R;
import com.papahouse.customer.model.MenuItemModel;

import java.util.ArrayList;
import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.VH> {

    public interface OnAddClick {
        void onAdd(MenuItemModel item);
    }

    private final List<MenuItemModel> data = new ArrayList<>();
    private final OnAddClick listener;

    public MenuAdapter(OnAddClick listener) {
        this.listener = listener;
    }

    // 🔹 Update data list
    public void submit(List<MenuItemModel> list) {
        data.clear();
        data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_menu, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        MenuItemModel item = data.get(position);

        // 🖼️ Set local drawable image
        holder.img.setImageResource(item.imageRes);

        // 🍔 Set name, code, and price
        holder.txtName.setText(item.name);
        holder.txtCode.setText("Code: " + item.id);
        holder.txtPrice.setText(String.format("RM %.2f", item.price));

        // 🛒 Add to cart action
        holder.btnAdd.setOnClickListener(v -> listener.onAdd(item));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView img;
        TextView txtName, txtCode, txtPrice;
        MaterialButton btnAdd;

        VH(@NonNull View v) {
            super(v);
            img = v.findViewById(R.id.img);
            txtName = v.findViewById(R.id.txtName);
            txtCode = v.findViewById(R.id.txtCode);
            txtPrice = v.findViewById(R.id.txtPrice);
            btnAdd = v.findViewById(R.id.btnAdd);
        }
    }
}
