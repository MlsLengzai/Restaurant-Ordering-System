package com.example.papahouseadmin.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.List;

public class DeclinedOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private ArrayList<OrderModel> orders = new ArrayList<>();
    private FirebaseFirestore db;

    // UI Elements
    private LinearLayout selectionBar;
    private Button btnSelectMode, btnClearAll, btnCancelSelect, btnDeleteSelected;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Ensure this layout matches your XML filename
        View view = inflater.inflate(R.layout.fragment_declined_orders, container, false);

        db = FirebaseFirestore.getInstance();

        // Init Views (Make sure IDs match fragment_declined_orders.xml)
        recyclerView = view.findViewById(R.id.rvDeclinedOrders);
        selectionBar = view.findViewById(R.id.selectionBar);
        btnSelectMode = view.findViewById(R.id.btnSelectMode);
        btnClearAll = view.findViewById(R.id.btnClearAll);
        btnCancelSelect = view.findViewById(R.id.btnCancelSelect);
        btnDeleteSelected = view.findViewById(R.id.btnDeleteSelected);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(orders, false); // false = no standard action buttons
        recyclerView.setAdapter(adapter);

        setupButtons();
        loadDeclinedOrders();

        return view;
    }

    private void setupButtons() {
        // 1. Clear All Button
        btnClearAll.setOnClickListener(v -> {
            new AlertDialog.Builder(getContext())
                    .setTitle("Clear All History")
                    .setMessage("Are you sure you want to delete ALL declined orders permanently?")
                    .setPositiveButton("Delete All", (d, w) -> deleteAllOrders())
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // 2. Enable Selection Mode
        btnSelectMode.setOnClickListener(v -> {
            adapter.setSelectionMode(true);
            toggleActionBars(true);
        });

        // 3. Cancel Selection Mode
        btnCancelSelect.setOnClickListener(v -> {
            adapter.setSelectionMode(false);
            toggleActionBars(false);
        });

        // 4. Delete Selected Items
        btnDeleteSelected.setOnClickListener(v -> {
            List<String> toDelete = adapter.getSelectedOrderIds();
            if (toDelete.isEmpty()) {
                Toast.makeText(getContext(), "No items selected", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(getContext())
                    .setTitle("Delete Selected")
                    .setMessage("Delete " + toDelete.size() + " orders?")
                    .setPositiveButton("Yes", (d, w) -> deleteSelectedOrders(toDelete))
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    private void toggleActionBars(boolean selectionActive) {
        if (selectionActive) {
            selectionBar.setVisibility(View.VISIBLE);
            btnSelectMode.setVisibility(View.GONE);
            btnClearAll.setVisibility(View.GONE);
        } else {
            selectionBar.setVisibility(View.GONE);
            btnSelectMode.setVisibility(View.VISIBLE);
            btnClearAll.setVisibility(View.VISIBLE);
        }
    }

    // --- FIRESTORE OPERATIONS ---

    private void deleteAllOrders() {
        // Query only 'Declined' orders
        db.collection("orders")
                .whereEqualTo("status", "Declined")
                .get()
                .addOnSuccessListener(snapshot -> {
                    WriteBatch batch = db.batch();
                    for (QueryDocumentSnapshot doc : snapshot) {
                        batch.delete(doc.getReference());
                    }
                    batch.commit().addOnSuccessListener(aVoid -> {
                        Toast.makeText(getContext(), "Declined History Cleared", Toast.LENGTH_SHORT).show();
                    });
                });
    }

    private void deleteSelectedOrders(List<String> ids) {
        WriteBatch batch = db.batch();
        for (String id : ids) {
            batch.delete(db.collection("orders").document(id));
        }
        batch.commit().addOnSuccessListener(aVoid -> {
            Toast.makeText(getContext(), "Selected orders deleted", Toast.LENGTH_SHORT).show();
            adapter.setSelectionMode(false); // Exit selection mode
            toggleActionBars(false);
        });
    }

    private void loadDeclinedOrders() {
        db.collection("orders")
                .whereEqualTo("status", "Declined") // Only fetch Declined
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null) return;
                    orders.clear();
                    for (QueryDocumentSnapshot doc : value) {
                        orders.add(doc.toObject(OrderModel.class));
                    }
                    adapter.notifyDataSetChanged();
                });
    }
}