package com.example.papahouseadmin;

import java.util.List;

public class OrderModel {

    private String orderId;
    private double total;
    private String method;
    private String status;
    private long timestamp;

    private List<CartItem> items;

    public OrderModel() {}

    // ------------------ GETTERS ------------------ //
    public String getOrderId() { return orderId; }
    public double getTotal() { return total; }
    public String getMethod() { return method; }
    public String getStatus() { return status; }
    public long getTimestamp() { return timestamp; }
    public List<CartItem> getItems() { return items; }

    // ------------------ SETTERS (REQUIRED) ------------------ //
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public void setTotal(double total) { this.total = total; }
    public void setMethod(String method) { this.method = method; }
    public void setStatus(String status) { this.status = status; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public void setItems(List<CartItem> items) { this.items = items; }

    // ------------------ EXTRA HELPERS ------------------ //
    public String getFirstItemName() {
        if (items != null && !items.isEmpty() && items.get(0).item != null) {
            return items.get(0).item.name;
        }
        return "Item";
    }

    /** Item summary for the card */
    public String getSummary() {
        if (items == null) return "";

        StringBuilder sb = new StringBuilder();
        for (CartItem c : items) {
            sb.append(c.qty).append(" × ");

            sb.append(c.item != null ? c.item.name : "Item");

            if (c.drinkType != null && !c.drinkType.isEmpty())
                sb.append(" (").append(c.drinkType).append(")");

            if (c.remark != null && !c.remark.isEmpty())
                sb.append(" - ").append(c.remark);

            sb.append("\n");
        }
        return sb.toString().trim();
    }

    // ------------------ INNER MODELS ------------------ //
    public static class CartItem {
        public MenuItemModel item;
        public int qty;
        public String remark;
        public String drinkType;

        public CartItem() {}
    }

    public static class MenuItemModel {
        public String id;
        public String name;
        public double price;
        public int imageRes;
        public String category;

        public MenuItemModel() {}
    }
}
