package com.example.papahouseadmin;

import java.util.List;
import java.util.Locale;

public class OrderModel {

    private String orderId;
    private double total;
    private String method;
    private String orderType; // "Dine-in" or "Takeaway"
    private String status;
    private long timestamp;
    private List<CartItem> items;

    public OrderModel() {}

    public String getOrderId() { return orderId; }
    public double getTotal() { return total; }
    public String getMethod() { return method != null ? method : "Pay at Counter"; }
    public String getStatus() { return status != null ? status : "Pending"; }
    public long getTimestamp() { return timestamp; }
    public List<CartItem> getItems() { return items; }
    public String getOrderType() { return orderType != null ? orderType : "Dine-in"; }

    public void setOrderId(String orderId) { this.orderId = orderId; }
    public void setTotal(double total) { this.total = total; }
    public void setMethod(String method) { this.method = method; }
    public void setStatus(String status) { this.status = status; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public void setItems(List<CartItem> items) { this.items = items; }
    public void setOrderType(String orderType) { this.orderType = orderType; }

    public String getSummary() {
        if (items == null || items.isEmpty()) return "No items";

        StringBuilder sb = new StringBuilder();
        for (CartItem c : items) {
            sb.append(c.qty).append("x ");

            // SAFE CHECK: Check if item exists
            if (c.item != null && c.item.name != null) {
                sb.append(c.item.name);
            } else {
                sb.append("Unknown Item");
            }

            if (c.drinkType != null && !c.drinkType.isEmpty()) {
                sb.append(" (").append(c.drinkType).append(")");
            }

            // SAFE CHECK: Calculate Price
            double linePrice = 0;
            if (c.item != null) {
                linePrice = c.item.price * c.qty;
            }
            sb.append(String.format(Locale.getDefault(), " (RM %.2f)", linePrice));
            sb.append("\n");
        }
        return sb.toString().trim();
    }

    public static class CartItem {
        public MenuItemModel item;
        public int qty;
        public String remark;
        public String drinkType;

        public CartItem() {}
    }

    public static class MenuItemModel {
        public String id;
        public String name;
        public double price;
        public String category;

        public MenuItemModel() {}
    }
}