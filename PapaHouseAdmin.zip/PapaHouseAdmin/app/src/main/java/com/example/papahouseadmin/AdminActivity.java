package com.example.papahouseadmin;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.papahouseadmin.fragments.CompletedOrdersFragment;
import com.example.papahouseadmin.fragments.DeclinedOrdersFragment;
import com.example.papahouseadmin.fragments.PendingOrdersFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AdminActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        bottomNav = findViewById(R.id.bottom_nav);

        if (savedInstanceState == null) {
            loadFragment(new PendingOrdersFragment());
            bottomNav.setSelectedItemId(R.id.nav_pending);
        }

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment f = null;
            int id = item.getItemId();

            if (id == R.id.nav_pending) {
                f = new PendingOrdersFragment();
            } else if (id == R.id.nav_completed) {
                f = new CompletedOrdersFragment();
            } else if (id == R.id.nav_declined) {
                f = new DeclinedOrdersFragment();
            }

            if (f != null) {
                loadFragment(f);
                return true;
            }
            return false;
        });
    }

    private void loadFragment(@NonNull Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
