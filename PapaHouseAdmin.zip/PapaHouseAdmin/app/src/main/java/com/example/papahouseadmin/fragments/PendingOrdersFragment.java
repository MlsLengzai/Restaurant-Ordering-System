package com.example.papahouseadmin.fragments;

import android.content.Context;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class PendingOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private ArrayList<OrderModel> orders = new ArrayList<>();

    private FirebaseFirestore db;

    private TextView txtTotalSales;
    private TextView txtOrderCount;

    private int lastCount = -1;   // for detecting NEW orders

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_pending_orders, container, false);

        recyclerView = view.findViewById(R.id.rvPendingOrders);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new OrderAdapter(orders, true);   // true = show action buttons
        recyclerView.setAdapter(adapter);

        txtTotalSales = view.findViewById(R.id.txtTotalSales);
        txtOrderCount = view.findViewById(R.id.txtOrderCount);

        db = FirebaseFirestore.getInstance();

        loadPendingOrders();

        return view;
    }

    private void loadPendingOrders() {
        db.collection("orders")
                .whereEqualTo("status", "Pending")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value,
                                        @Nullable FirebaseFirestoreException error) {

                        if (error != null || value == null) return;

                        // detect NEW orders (for sound)
                        int newCount = value.size();
                        if (lastCount != -1 && newCount > lastCount) {
                            playNewOrderSound(requireContext());
                        }
                        lastCount = newCount;

                        orders.clear();
                        double totalSales = 0;
                        int totalOrders = 0;

                        for (QueryDocumentSnapshot doc : value) {
                            OrderModel m = doc.toObject(OrderModel.class);
                            orders.add(m);
                            totalSales += m.getTotal();
                            totalOrders++;
                        }

                        txtTotalSales.setText(
                                String.format("RM %.2f", totalSales)
                        );
                        txtOrderCount.setText(String.valueOf(totalOrders));

                        adapter.notifyDataSetChanged();
                    }
                });
    }

    private void playNewOrderSound(Context context) {
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(context, notification);
            r.play();
        } catch (Exception ignored) {
        }
    }
}
