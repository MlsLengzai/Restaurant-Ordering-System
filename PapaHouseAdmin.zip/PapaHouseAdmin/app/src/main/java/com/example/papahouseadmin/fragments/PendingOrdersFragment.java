package com.example.papahouseadmin.fragments;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.AdminActivity;
import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class PendingOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private ArrayList<OrderModel> orders = new ArrayList<>();
    private FirebaseFirestore db;
    private TextView txtTotalSales, txtOrderCount;
    private int lastCount = 0;
    private boolean isFirstLoad = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pending_orders, container, false);

        recyclerView = view.findViewById(R.id.rvPendingOrders);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new OrderAdapter(orders, true);
        recyclerView.setAdapter(adapter);

        txtTotalSales = view.findViewById(R.id.txtTotalSales);
        txtOrderCount = view.findViewById(R.id.txtOrderCount);

        db = FirebaseFirestore.getInstance();
        loadPendingOrders();

        // Request Notification Permission (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        return view;
    }

    private void loadPendingOrders() {
        db.collection("orders")
                .whereEqualTo("status", "Pending")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        // CRASH FIX: Check if fragment is still active
                        if (!isAdded() || getContext() == null) return;
                        if (error != null || value == null) return;

                        int newCount = value.size();

                        // NOTIFICATION LOGIC
                        if (!isFirstLoad && newCount > lastCount) {
                            sendNotification("New Order!", "You have " + newCount + " pending orders.");
                        }

                        lastCount = newCount;
                        isFirstLoad = false;

                        orders.clear();
                        double totalSales = 0;
                        int totalOrders = 0;

                        for (QueryDocumentSnapshot doc : value) {
                            try {
                                OrderModel m = doc.toObject(OrderModel.class);
                                orders.add(m);
                                totalSales += m.getTotal();
                                totalOrders++;
                            } catch (Exception e) {
                                // Ignore bad data to prevent crash
                            }
                        }

                        txtTotalSales.setText(String.format("RM %.2f", totalSales));
                        txtOrderCount.setText(String.valueOf(totalOrders));
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    private void sendNotification(String title, String message) {
        if (getContext() == null) return;

        // Permission Check
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return; // Don't crash if no permission
            }
        }

        String channelId = "new_order_channel";
        NotificationManager manager = (NotificationManager) requireContext().getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "New Orders", NotificationManager.IMPORTANCE_HIGH);
            channel.enableVibration(true);
            manager.createNotificationChannel(channel);
        }

        Intent intent = new Intent(requireContext(), AdminActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(requireContext(), 0, intent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(requireContext(), channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        manager.notify(1001, builder.build());

        // Sound
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getContext(), notification);
            r.play();
        } catch (Exception ignored) {}
    }
}