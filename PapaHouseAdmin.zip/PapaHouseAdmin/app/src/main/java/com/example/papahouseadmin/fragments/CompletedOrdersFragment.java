package com.example.papahouseadmin.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class CompletedOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private ArrayList<OrderModel> orders = new ArrayList<>();
    private FirebaseFirestore db;

    private Button btnPreparing, btnReady, btnCompleted;
    private Button btnSelect, btnClear;
    private Button btnCancelSelect, btnDeleteSelected;
    private View selectionBar;

    private boolean isSelectionMode = false;
    private String currentFilter = "Preparing";

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_completed_orders, container, false);

        db = FirebaseFirestore.getInstance();

        // UI
        recyclerView = view.findViewById(R.id.rvCompletedOrders);
        btnPreparing = view.findViewById(R.id.btnPreparing);
        btnReady = view.findViewById(R.id.btnReady);
        btnCompleted = view.findViewById(R.id.btnCompleted);
        btnSelect = view.findViewById(R.id.btnSelectMode);
        btnClear = view.findViewById(R.id.btnClearAll);
        selectionBar = view.findViewById(R.id.selectionBar);
        btnCancelSelect = view.findViewById(R.id.btnCancelSelect);
        btnDeleteSelected = view.findViewById(R.id.btnDeleteSelected);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(orders, true);
        recyclerView.setAdapter(adapter);

        // Category buttons
        btnPreparing.setOnClickListener(v -> switchCategory("Preparing"));
        btnReady.setOnClickListener(v -> switchCategory("Ready"));
        btnCompleted.setOnClickListener(v -> switchCategory("Completed"));

        // Selection mode
        btnSelect.setOnClickListener(v -> {
            isSelectionMode = true;
            adapter.setSelectionMode(true);
            selectionBar.setVisibility(View.VISIBLE);
        });

        btnCancelSelect.setOnClickListener(v -> exitSelectionMode());

        btnDeleteSelected.setOnClickListener(v -> {
            List<String> selected = adapter.getSelectedOrderIds();
            if (selected.isEmpty()) {
                Toast.makeText(getContext(), "No orders selected", Toast.LENGTH_SHORT).show();
                return;
            }

            confirm("Delete selected orders?", "This action cannot be undone.",
                    () -> deleteOrders(selected));
        });

        btnClear.setOnClickListener(v -> {
            if (orders.isEmpty()) {
                Toast.makeText(getContext(), "No orders to clear", Toast.LENGTH_SHORT).show();
                return;
            }

            confirm("Clear all orders?",
                    "All orders in this category will be permanently deleted.",
                    this::deleteAllOrders);
        });

        loadFilteredOrders();
        return view;
    }

    // ================= FILTER =================
    private void switchCategory(String status) {
        currentFilter = status;
        loadFilteredOrders();
    }

    private void loadFilteredOrders() {
        db.collection("orders")
                .whereEqualTo("status", currentFilter)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null || !isAdded()) return;

                    orders.clear();
                    for (QueryDocumentSnapshot doc : value) {
                        OrderModel m = doc.toObject(OrderModel.class);
                        if (m != null) orders.add(m);
                    }
                    adapter.notifyDataSetChanged();
                });
    }

    // ================= DELETE =================
    private void deleteOrders(List<String> ids) {
        for (String id : ids) {
            db.collection("orders").document(id).delete();
        }
        Toast.makeText(getContext(), "Selected orders deleted", Toast.LENGTH_SHORT).show();
        exitSelectionMode();
    }

    private void deleteAllOrders() {
        for (OrderModel o : orders) {
            db.collection("orders").document(o.getOrderId()).delete();
        }
        Toast.makeText(getContext(), "Orders cleared", Toast.LENGTH_SHORT).show();
    }

    private void exitSelectionMode() {
        isSelectionMode = false;
        adapter.setSelectionMode(false);
        selectionBar.setVisibility(View.GONE);
    }

    // ================= CONFIRM =================
    private void confirm(String title, String msg, Runnable action) {
        new AlertDialog.Builder(requireContext())
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton("Delete", (d, w) -> action.run())
                .setNegativeButton("Cancel", null)
                .show();
    }
}
