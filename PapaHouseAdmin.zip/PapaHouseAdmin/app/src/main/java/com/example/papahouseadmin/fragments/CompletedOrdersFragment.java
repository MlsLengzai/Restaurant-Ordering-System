package com.example.papahouseadmin.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class CompletedOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;

    private final ArrayList<OrderModel> allOrders = new ArrayList<>();
    private final ArrayList<OrderModel> displayedOrders = new ArrayList<>();

    private FirebaseFirestore db;

    private MaterialButton btnPreparing, btnReady, btnCompleted;
    private String currentFilter = "Preparing";

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_completed_orders, container, false);

        recyclerView = view.findViewById(R.id.rvCompletedOrders);
        btnPreparing = view.findViewById(R.id.btnPreparing);
        btnReady = view.findViewById(R.id.btnReady);
        btnCompleted = view.findViewById(R.id.btnCompleted);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(displayedOrders, true);
        recyclerView.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();
        loadOrders();

        setupFilterButtons();

        return view;
    }

    private void setupFilterButtons() {
        btnPreparing.setOnClickListener(v -> {
            currentFilter = "Preparing";
            setActiveButton(btnPreparing, "#3B82F6");
            applyFilter();
        });

        btnReady.setOnClickListener(v -> {
            currentFilter = "Ready";
            setActiveButton(btnReady, "#10B981");
            applyFilter();
        });

        btnCompleted.setOnClickListener(v -> {
            currentFilter = "Completed";
            setActiveButton(btnCompleted, "#4CAF50");
            applyFilter();
        });

        // Default
        setActiveButton(btnPreparing, "#3B82F6");
    }

    private void setActiveButton(MaterialButton active, String colorHex) {
        resetButton(btnPreparing, "#3B82F6");
        resetButton(btnReady, "#10B981");
        resetButton(btnCompleted, "#4CAF50");

        int color = Color.parseColor(colorHex);
        active.setBackgroundColor(color);
        active.setTextColor(Color.WHITE);
        active.setStrokeWidth(0);
    }

    private void resetButton(MaterialButton btn, String colorHex) {
        int color = Color.parseColor(colorHex);
        btn.setBackgroundColor(Color.TRANSPARENT);
        btn.setTextColor(color);
        btn.setStrokeColor(android.content.res.ColorStateList.valueOf(color));
        btn.setStrokeWidth(3);
    }

    private void loadOrders() {
        db.collection("orders")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (value == null || !isAdded()) return;

                    allOrders.clear();
                    for (QueryDocumentSnapshot doc : value) {
                        OrderModel m = doc.toObject(OrderModel.class);
                        if (m != null &&
                                !"Pending".equals(m.getStatus()) &&
                                !"Declined".equals(m.getStatus())) {
                            allOrders.add(m);
                        }
                    }
                    applyFilter();
                });
    }

    private void applyFilter() {
        displayedOrders.clear();
        for (OrderModel o : allOrders) {
            if (o.getStatus().equalsIgnoreCase(currentFilter)) {
                displayedOrders.add(o);
            }
        }
        adapter.notifyDataSetChanged();
    }
}
