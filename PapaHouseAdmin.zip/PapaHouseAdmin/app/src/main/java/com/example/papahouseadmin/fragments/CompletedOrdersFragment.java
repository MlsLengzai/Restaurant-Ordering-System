package com.example.papahouseadmin.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CompletedOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private ArrayList<OrderModel> orders = new ArrayList<>();
    private FirebaseFirestore db;

    // UI Elements for Selection Mode
    private LinearLayout selectionBar;
    private Button btnSelectMode, btnClearAll, btnCancelSelect, btnDeleteSelected;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_completed_orders, container, false);

        db = FirebaseFirestore.getInstance();

        // 1. Initialize Views
        recyclerView = view.findViewById(R.id.rvCompletedOrders);
        selectionBar = view.findViewById(R.id.selectionBar);
        btnSelectMode = view.findViewById(R.id.btnSelectMode);
        btnClearAll = view.findViewById(R.id.btnClearAll);
        btnCancelSelect = view.findViewById(R.id.btnCancelSelect);
        btnDeleteSelected = view.findViewById(R.id.btnDeleteSelected);

        // 2. Setup Recycler
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(orders, false); // false = hide Pending buttons, enable click/select
        recyclerView.setAdapter(adapter);

        // 3. Load Data & Setup Buttons
        setupButtons();
        loadAcceptedOrders();

        return view;
    }

    private void setupButtons() {
        // Clear All Button
        btnClearAll.setOnClickListener(v -> {
            new AlertDialog.Builder(getContext())
                    .setTitle("Clear All Active Orders?")
                    .setMessage("WARNING: This will delete ALL 'Accepted', 'Preparing', and 'Ready' orders permanently. Continue?")
                    .setPositiveButton("Delete All", (d, w) -> deleteAllOrders())
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Enable Selection Mode
        btnSelectMode.setOnClickListener(v -> {
            adapter.setSelectionMode(true);
            toggleActionBars(true);
        });

        // Cancel Selection Mode
        btnCancelSelect.setOnClickListener(v -> {
            adapter.setSelectionMode(false);
            toggleActionBars(false);
        });

        // Delete Selected Items
        btnDeleteSelected.setOnClickListener(v -> {
            List<String> toDelete = adapter.getSelectedOrderIds();
            if (toDelete.isEmpty()) {
                Toast.makeText(getContext(), "No items selected", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(getContext())
                    .setTitle("Delete Selected")
                    .setMessage("Delete " + toDelete.size() + " orders?")
                    .setPositiveButton("Yes", (d, w) -> deleteSelectedOrders(toDelete))
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    private void toggleActionBars(boolean selectionActive) {
        if (selectionActive) {
            selectionBar.setVisibility(View.VISIBLE);
            btnSelectMode.setVisibility(View.GONE);
            btnClearAll.setVisibility(View.GONE);
        } else {
            selectionBar.setVisibility(View.GONE);
            btnSelectMode.setVisibility(View.VISIBLE);
            btnClearAll.setVisibility(View.VISIBLE);
        }
    }

    // --- FIRESTORE DELETE OPERATIONS ---

    private void deleteAllOrders() {
        // Deletes all orders currently visible in this list (Accepted, Preparing, Ready)
        db.collection("orders")
                .whereIn("status", Arrays.asList("Accepted", "Preparing", "Ready"))
                .get()
                .addOnSuccessListener(snapshot -> {
                    WriteBatch batch = db.batch();
                    for (QueryDocumentSnapshot doc : snapshot) {
                        batch.delete(doc.getReference());
                    }
                    batch.commit().addOnSuccessListener(aVoid -> {
                        Toast.makeText(getContext(), "All Active Orders Cleared", Toast.LENGTH_SHORT).show();
                    });
                });
    }

    private void deleteSelectedOrders(List<String> ids) {
        WriteBatch batch = db.batch();
        for (String id : ids) {
            batch.delete(db.collection("orders").document(id));
        }
        batch.commit().addOnSuccessListener(aVoid -> {
            Toast.makeText(getContext(), "Selected orders deleted", Toast.LENGTH_SHORT).show();
            adapter.setSelectionMode(false);
            toggleActionBars(false);
        });
    }

    private void loadAcceptedOrders() {
        // Load orders that are Accepted, Preparing, or Ready
        db.collection("orders")
                .whereIn("status", Arrays.asList("Accepted", "Preparing", "Ready"))
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null || value == null) return;

                        orders.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            orders.add(doc.toObject(OrderModel.class));
                        }
                        adapter.notifyDataSetChanged();
                    }
                });
    }
}