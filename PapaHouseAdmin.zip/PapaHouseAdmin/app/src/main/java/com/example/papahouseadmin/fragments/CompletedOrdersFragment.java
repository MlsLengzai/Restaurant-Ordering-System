package com.example.papahouseadmin.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.papahouseadmin.OrderAdapter;
import com.example.papahouseadmin.OrderModel;
import com.example.papahouseadmin.R;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;

public class CompletedOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private OrderAdapter adapter;
    private ArrayList<OrderModel> orders = new ArrayList<>();
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_completed_orders, container, false);

        recyclerView = view.findViewById(R.id.rvCompletedOrders);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // We pass 'false' because standard buttons are hidden, we use Dialog click instead
        adapter = new OrderAdapter(orders, false);
        recyclerView.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();
        loadAcceptedOrders();

        return view;
    }

    private void loadAcceptedOrders() {
        // Fetch ALL active statuses: Accepted, Preparing, Ready
        db.collection("orders")
                .whereIn("status", Arrays.asList("Accepted", "Preparing", "Ready"))
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null || value == null) return;

                        orders.clear();
                        for (QueryDocumentSnapshot doc : value) {
                            orders.add(doc.toObject(OrderModel.class));
                        }
                        adapter.notifyDataSetChanged();
                    }
                });
    }
}