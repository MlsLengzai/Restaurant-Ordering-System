package com.example.papahouseadmin;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private ArrayList<OrderModel> orderList;
    private boolean showActions; // True only for Pending Tab
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    // --- SELECTION MODE VARIABLES (Restored) ---
    private boolean isSelectionMode = false;
    private Set<String> selectedOrderIds = new HashSet<>();

    public OrderAdapter(ArrayList<OrderModel> orders, boolean showActions) {
        this.orderList = orders;
        this.showActions = showActions;
    }

    // --- SELECTION METHODS (Required for Declined/Completed Fragment) ---
    public void setSelectionMode(boolean enabled) {
        this.isSelectionMode = enabled;
        this.selectedOrderIds.clear(); // Clear selections when toggling
        notifyDataSetChanged();
    }

    public void toggleSelection(String orderId) {
        if (selectedOrderIds.contains(orderId)) {
            selectedOrderIds.remove(orderId);
        } else {
            selectedOrderIds.add(orderId);
        }
        notifyDataSetChanged();
    }

    public List<String> getSelectedOrderIds() {
        return new ArrayList<>(selectedOrderIds);
    }
    // ------------------------------------------------------------------

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder h, int position) {
        OrderModel o = orderList.get(position);

        // 1. Bind Basic Data
        h.txtOrderId.setText("Order #" + o.getOrderId());
        h.txtStatus.setText(o.getStatus());
        h.txtMethod.setText(o.getMethod());
        h.txtItems.setText(o.getSummary());
        h.txtTotal.setText(String.format(Locale.getDefault(), "RM %.2f", o.getTotal()));

        String time = new SimpleDateFormat("hh:mm a", Locale.getDefault())
                .format(new Date(o.getTimestamp()));
        h.txtTime.setText(time);
        h.imgFirstItem.setImageResource(R.drawable.ic_food_placeholder);

        // ==================================================================
        // LOGIC 1: SELECTION MODE (Overrides everything else)
        // ==================================================================
        if (isSelectionMode) {
            h.layoutButtons.setVisibility(View.GONE); // Hide buttons
            h.itemView.setOnClickListener(v -> toggleSelection(o.getOrderId()));

            if (selectedOrderIds.contains(o.getOrderId())) {
                h.itemView.setBackgroundColor(Color.LTGRAY); // Highlight Selected
            } else {
                h.itemView.setBackgroundColor(Color.WHITE);
            }
            return; // Stop here, don't run button logic
        }

        // ==================================================================
        // LOGIC 2: NORMAL MODE
        // ==================================================================
        h.itemView.setBackgroundColor(Color.WHITE);

        // CASE A: Pending Tab (Status is Pending)
        if (o.getStatus().equals("Pending")) {
            h.layoutButtons.setVisibility(View.VISIBLE);
            h.btnAccept.setText("Accept");

            // Accept -> Moves to "Accepted" status
            h.btnAccept.setOnClickListener(v ->
                    updateStatus(o, position, "Accepted"));

            // Decline -> Moves to "Declined"
            h.btnDecline.setOnClickListener(v ->
                    confirm(v.getContext(), "Decline Order?", () -> updateStatus(o, position, "Declined")));

            // Disable clicking the card itself in Pending
            h.itemView.setOnClickListener(null);
        }

        // CASE B: Accepted / History Tabs (Click to Open Dialog)
        else {
            h.layoutButtons.setVisibility(View.GONE); // Hide buttons

            // Enable Click on the whole card to open Dialog
            h.itemView.setOnClickListener(v -> showStatusDialog(v.getContext(), o));
        }

        // Animation
        h.itemView.startAnimation(AnimationUtils.loadAnimation(h.itemView.getContext(), android.R.anim.fade_in));
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    // --- DIALOG: Select Status ---
    private void showStatusDialog(Context context, OrderModel order) {
        String[] options = {"Mark In Process (Preparing)", "Mark Ready for Pickup", "Mark Completed"};

        new AlertDialog.Builder(context)
                .setTitle("Update Status: #" + order.getOrderId())
                .setItems(options, (dialog, which) -> {
                    String newStatus = "";
                    switch (which) {
                        case 0: newStatus = "Preparing"; break;
                        case 1: newStatus = "Ready"; break;
                        case 2: newStatus = "Completed"; break;
                    }
                    updateStatus(order, -1, newStatus);
                })
                .show();
    }

    // --- HELPER: Update Firestore ---
    private void updateStatus(OrderModel o, int position, String newStatus) {
        o.setStatus(newStatus);
        if(position != -1) notifyItemChanged(position); // Immediate UI feedback

        db.collection("orders").document(o.getOrderId())
                .update("status", newStatus)
                .addOnSuccessListener(aVoid -> {
                    // Success
                })
                .addOnFailureListener(e -> {
                    // Handle failure if needed
                });
    }

    private void confirm(Context ctx, String msg, Runnable action) {
        new AlertDialog.Builder(ctx).setTitle("Confirm").setMessage(msg)
                .setPositiveButton("Yes", (d,w)->action.run())
                .setNegativeButton("No", null).show();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView txtOrderId, txtItems, txtTotal, txtStatus, txtTime, txtMethod;
        LinearLayout layoutButtons;
        Button btnAccept, btnDecline;
        ImageView imgFirstItem;

        public OrderViewHolder(@NonNull View v) {
            super(v);
            txtOrderId = v.findViewById(R.id.txtOrderId);
            txtItems = v.findViewById(R.id.txtItems);
            txtTotal = v.findViewById(R.id.txtTotal);
            txtStatus = v.findViewById(R.id.txtStatus);
            txtTime = v.findViewById(R.id.txtTime);
            txtMethod = v.findViewById(R.id.txtMethod);
            imgFirstItem = v.findViewById(R.id.imgFirstItem);
            layoutButtons = v.findViewById(R.id.layoutButtons);
            btnAccept = v.findViewById(R.id.btnAccept);
            btnDecline = v.findViewById(R.id.btnDecline);
        }
    }
}