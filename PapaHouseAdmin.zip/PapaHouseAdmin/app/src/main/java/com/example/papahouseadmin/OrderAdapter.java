package com.example.papahouseadmin;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private ArrayList<OrderModel> orderList;
    private boolean showActions;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    // Selection mode
    private boolean isSelectionMode = false;
    private Set<String> selectedOrderIds = new HashSet<>();

    public OrderAdapter(ArrayList<OrderModel> orders, boolean showActions) {
        this.orderList = orders;
        this.showActions = showActions;
    }

    // ---------------- Selection Mode ----------------

    public void setSelectionMode(boolean enabled) {
        this.isSelectionMode = enabled;
        selectedOrderIds.clear();
        notifyDataSetChanged();
    }

    public void toggleSelection(String orderId) {
        if (selectedOrderIds.contains(orderId)) {
            selectedOrderIds.remove(orderId);
        } else {
            selectedOrderIds.add(orderId);
        }
        notifyDataSetChanged();
    }

    public List<String> getSelectedOrderIds() {
        return new ArrayList<>(selectedOrderIds);
    }

    // ---------------- Adapter ----------------

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder h, int position) {
        OrderModel o = orderList.get(position);

        // ==================================================
        // RESET VIEW STATE (VERY IMPORTANT FOR RECYCLERVIEW)
        // ==================================================
        h.layoutButtons.setVisibility(View.GONE);
        h.btnAccept.setVisibility(View.GONE);
        h.btnDecline.setVisibility(View.GONE);
        h.txtStatus.setVisibility(View.VISIBLE);
        h.itemView.setBackgroundColor(Color.WHITE);
        h.itemView.setOnClickListener(null);

        // ---------------- Bind Data ----------------
        h.txtOrderId.setText("Order #" + o.getOrderId());
        h.txtMethod.setText(o.getMethod());
        h.txtItems.setText(o.getSummary());
        h.txtTotal.setText(String.format(Locale.getDefault(), "RM %.2f", o.getTotal()));

        String time = new SimpleDateFormat("hh:mm a", Locale.getDefault())
                .format(new Date(o.getTimestamp()));
        h.txtTime.setText(time);

        // ---------------- Order Type Badge ----------------
        String type = o.getOrderType();
        h.txtOrderType.setText(type != null ? type.toUpperCase() : "ORDER");

        if ("Takeaway".equalsIgnoreCase(type)) {
            h.txtOrderType.setBackgroundColor(Color.parseColor("#6200EE"));
            h.txtOrderType.setTextColor(Color.WHITE);
        } else {
            h.txtOrderType.setBackgroundColor(Color.parseColor("#E0E0E0"));
            h.txtOrderType.setTextColor(Color.parseColor("#555555"));
        }

        // ---------------- Status Chip ----------------
        h.txtStatus.setText(o.getStatus());
        int statusColor = Color.GRAY;
        switch (o.getStatus()) {
            case "Pending":
                statusColor = Color.parseColor("#F59E0B"); // Orange
                break;
            case "Preparing":
                statusColor = Color.parseColor("#3B82F6"); // Blue
                break;
            case "Ready":
                statusColor = Color.parseColor("#10B981"); // Green
                break;
            case "Completed":
                statusColor = Color.parseColor("#4CAF50"); // Dark Green
                break;
        }
        h.txtStatus.setBackgroundColor(statusColor);

        // ==================================================
        // SELECTION MODE (Bulk delete only)
        // ==================================================
        if (isSelectionMode) {
            h.itemView.setBackgroundColor(
                    selectedOrderIds.contains(o.getOrderId())
                            ? Color.LTGRAY
                            : Color.WHITE
            );
            h.itemView.setOnClickListener(v -> toggleSelection(o.getOrderId()));
            return;
        }

        // ==================================================
        // STATUS-BASED UI LOGIC
        // ==================================================

        if ("Pending".equals(o.getStatus())) {
            // Pending → Show ACCEPT / DECLINE
            h.layoutButtons.setVisibility(View.VISIBLE);
            h.txtStatus.setVisibility(View.GONE);

            h.btnAccept.setText("ACCEPT");
            h.btnAccept.setVisibility(View.VISIBLE);
            h.btnAccept.setOnClickListener(v ->
                    updateStatus(o, position, "Preparing")
            );

            h.btnDecline.setText("DECLINE");
            h.btnDecline.setVisibility(View.VISIBLE);
            h.btnDecline.setTextColor(Color.parseColor("#D32F2F"));
            h.btnDecline.setOnClickListener(v ->
                    confirm(v.getContext(), "Decline this order?", () ->
                            updateStatus(o, position, "Declined"))
            );

        } else if ("Completed".equals(o.getStatus())) {
            // Completed → STATUS ONLY (NO BUTTONS)
            h.layoutButtons.setVisibility(View.GONE);
            h.txtStatus.setVisibility(View.VISIBLE);

        } else {
            // Preparing / Ready → Tap to update status
            h.itemView.setOnClickListener(v ->
                    showStatusDialog(v.getContext(), o)
            );
        }

        h.itemView.startAnimation(
                AnimationUtils.loadAnimation(h.itemView.getContext(), android.R.anim.fade_in)
        );
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    // ---------------- Dialogs & Firestore ----------------

    private void showStatusDialog(Context context, OrderModel order) {
        String[] options = {"Mark Preparing", "Mark Ready for Pickup", "Mark Completed"};
        new AlertDialog.Builder(context)
                .setTitle("Update Status: #" + order.getOrderId())
                .setItems(options, (dialog, which) -> {
                    String newStatus;
                    switch (which) {
                        case 0:
                            newStatus = "Preparing";
                            break;
                        case 1:
                            newStatus = "Ready";
                            break;
                        default:
                            newStatus = "Completed";
                            break;
                    }
                    updateStatus(order, -1, newStatus);
                })
                .show();
    }

    private void updateStatus(OrderModel o, int position, String newStatus) {
        o.setStatus(newStatus);
        if (position != -1) notifyItemChanged(position);
        db.collection("orders")
                .document(o.getOrderId())
                .update("status", newStatus);
    }

    private void confirm(Context ctx, String msg, Runnable action) {
        new AlertDialog.Builder(ctx)
                .setTitle("Confirm")
                .setMessage(msg)
                .setPositiveButton("Yes", (d, w) -> action.run())
                .setNegativeButton("No", null)
                .show();
    }

    // ---------------- ViewHolder ----------------

    static class OrderViewHolder extends RecyclerView.ViewHolder {

        TextView txtOrderId, txtItems, txtTotal, txtStatus, txtTime, txtMethod, txtOrderType;
        LinearLayout layoutButtons;
        Button btnAccept, btnDecline;

        public OrderViewHolder(@NonNull View v) {
            super(v);
            txtOrderId = v.findViewById(R.id.txtOrderId);
            txtOrderType = v.findViewById(R.id.txtOrderType);
            txtItems = v.findViewById(R.id.txtItems);
            txtTotal = v.findViewById(R.id.txtTotal);
            txtStatus = v.findViewById(R.id.txtStatus);
            txtTime = v.findViewById(R.id.txtTime);
            txtMethod = v.findViewById(R.id.txtMethod);
            layoutButtons = v.findViewById(R.id.layoutButtons);
            btnAccept = v.findViewById(R.id.btnAccept);
            btnDecline = v.findViewById(R.id.btnDecline);
        }
    }
}
