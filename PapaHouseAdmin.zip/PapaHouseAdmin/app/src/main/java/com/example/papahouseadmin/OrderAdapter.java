package com.example.papahouseadmin;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private ArrayList<OrderModel> orderList;
    private boolean showActions;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    public OrderAdapter(ArrayList<OrderModel> orders, boolean showActions) {
        this.orderList = orders;
        this.showActions = showActions;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder h, int pos) {
        OrderModel o = orderList.get(pos);

        h.txtOrderId.setText("Order #" + o.getOrderId());
        h.txtStatus.setText(o.getStatus());
        h.txtMethod.setText("Method: " + o.getMethod());
        h.txtItems.setText(o.getSummary());
        h.txtTotal.setText(String.format(Locale.getDefault(), "RM %.2f", o.getTotal()));

        String time = new SimpleDateFormat("hh:mm a", Locale.getDefault())
                .format(new Date(o.getTimestamp()));
        h.txtTime.setText(time);

        // Placeholder only
        h.imgFirstItem.setImageResource(R.drawable.ic_food_placeholder);

        // ----- OPTION C: only show NEXT button -----
        if (showActions) {
            h.layoutButtons.setVisibility(View.VISIBLE);

            h.btnDecline.setText("Decline");
            h.btnAccept.setText(getNextButtonLabel(o.getStatus()));

            h.btnAccept.setOnClickListener(v ->
                    confirm(v.getContext(),
                            "Move to: " + getNextStatus(o.getStatus()) + "?",
                            () -> updateStatusAndRemove(o, pos, getNextStatus(o.getStatus())))
            );

            h.btnDecline.setOnClickListener(v ->
                    confirm(v.getContext(),
                            "Decline this order?",
                            () -> updateStatusAndRemove(o, pos, "Declined"))
            );
        } else {
            h.layoutButtons.setVisibility(View.GONE);
        }

        h.itemView.startAnimation(
                AnimationUtils.loadAnimation(h.itemView.getContext(), android.R.anim.fade_in)
        );
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    // STATUS FLOW
    private String getNextStatus(String current) {
        switch (current) {
            case "Pending": return "Accepted";
            case "Accepted": return "In Progress";
            case "In Progress": return "Ready for Pickup";
            case "Ready for Pickup": return "Completed";
            default: return current;
        }
    }

    private String getNextButtonLabel(String currentStatus) {
        switch (currentStatus) {
            case "Pending": return "Accept Order";
            case "Accepted": return "Start Preparing";
            case "In Progress": return "Mark Ready";
            case "Ready for Pickup": return "Complete Order";
            default: return "";
        }
    }

    private void confirm(Context ctx, String msg, Runnable next) {
        new AlertDialog.Builder(ctx)
                .setTitle("Confirm Action")
                .setMessage(msg)
                .setPositiveButton("Yes", (d,w)->next.run())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateStatusAndRemove(OrderModel o, int pos, String newStatus) {
        o.setStatus(newStatus);

        db.collection("orders")
                .document(o.getOrderId())
                .update("status", newStatus)
                .addOnSuccessListener(unused -> {
                    notifyItemChanged(pos);
                });
    }

    // VIEW HOLDER
    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView txtOrderId, txtItems, txtTotal, txtStatus, txtTime, txtMethod;
        LinearLayout layoutButtons;
        Button btnAccept, btnDecline;
        ImageView imgFirstItem;

        public OrderViewHolder(@NonNull View v) {
            super(v);

            txtOrderId = v.findViewById(R.id.txtOrderId);
            txtItems = v.findViewById(R.id.txtItems);
            txtTotal = v.findViewById(R.id.txtTotal);
            txtStatus = v.findViewById(R.id.txtStatus);
            txtTime = v.findViewById(R.id.txtTime);
            txtMethod = v.findViewById(R.id.txtMethod);

            imgFirstItem = v.findViewById(R.id.imgFirstItem);

            layoutButtons = v.findViewById(R.id.layoutButtons);
            btnAccept = v.findViewById(R.id.btnAccept);
            btnDecline = v.findViewById(R.id.btnDecline);
        }
    }
}
